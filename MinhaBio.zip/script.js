//*código para o gio em tempo real no rodape*//
  const options = {
	timeZone: 'America/Sao_Paulo',
	hour: 'numeric',
	minute: 'numeric'
};
const date = new Intl.DateTimeFormat([], options);
console.log(date.format(new Date()));


$('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});


//*código para contador de visitas*//

<a href="https://www.webcontadores.com" title="contador de visitas"><img src="https://counter9.stat.ovh/private/webcontadores.php?c=5sdk26uh3r8rcq1sxqjypmg8ftdbwfdk" border="0" title="contador de visitas" alt="contador de visitas"></a>










