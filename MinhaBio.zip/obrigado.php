<?php

if(isset($_POST(['email'])) && !empty )



$nome = addslashes($_POST(['name']))
$email = addslashes($_POST(['email']))
$mensagem = addslashes($_POST(['message']))





?>